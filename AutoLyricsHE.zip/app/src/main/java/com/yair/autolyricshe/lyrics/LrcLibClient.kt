package com.yair.autolyricshe.lyrics

import com.yair.autolyricshe.media.MediaTracker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Collections

/** Result of a lyrics lookup: timed lines (may be empty) and/or full plain text (may be null). */
data class LyricsResult(
    val synced: List<MediaTracker.Line>,
    val plain: String?
) {
    val isEmpty: Boolean get() = synced.isEmpty() && plain.isNullOrBlank()
}

object LrcLibClient {

    // Remembers recently found songs so replays / service restarts are instant.
    private const val CACHE_MAX = 60
    private val cache: MutableMap<String, LyricsResult> =
        Collections.synchronizedMap(object : LinkedHashMap<String, LyricsResult>(16, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, LyricsResult>) =
                size > CACHE_MAX
        })

    /**
     * Fires the most productive lookups CONCURRENTLY and takes the first synced result.
     * Total time is roughly one network round-trip instead of the sum of every attempt.
     */
    suspend fun fetch(title: String?, artist: String?, durationMs: Long): LyricsResult =
        withContext(Dispatchers.IO) {
            if (title.isNullOrBlank()) return@withContext LyricsResult(emptyList(), null)
            val durSec = if (durationMs > 0) durationMs / 1000 else 0L
            val ct = cleanForSearch(title).ifBlank { title }
            val ca = artist?.let { a -> cleanForSearch(a).ifBlank { a } }

            val key = "${ct.lowercase()}|${ca?.lowercase()}|$durSec"
            cache[key]?.let { return@withContext it }

            var synced = ""
            var plain = ""
            fun absorb(o: JSONObject?) {
                if (o == null) return
                val sy = o.optString("syncedLyrics")
                val pl = o.optString("plainLyrics")
                if (synced.isBlank() && sy.isNotBlank()) synced = sy
                if (plain.isBlank() && pl.isNotBlank()) plain = pl
            }

            coroutineScope {
                // Wave 1 — three parallel LRCLIB lookups (cover exact + fuzzy at once)
                val wave1 = listOf(
                    async { lrclibGet(title, artist, durSec) },   // exact title/artist + duration
                    async { lrclibSearchBest(ct, ca, durSec) },   // fuzzy search with artist
                    async { lrclibSearchBest(ct, null, durSec) }  // fuzzy search, title only
                ).awaitAll()
                wave1.forEach(::absorb)

                // Wave 2 — only if nothing synced yet: cleaned exact get + plain fallback
                if (synced.isBlank()) {
                    val wave2 = listOf(
                        async { if (durSec > 0) lrclibGet(ct, ca, 0) else null },
                        async { if (!ca.isNullOrBlank()) lyricsOvh(ct, ca) else null }
                    ).awaitAll()
                    wave2.forEach { v ->
                        when (v) {
                            is JSONObject -> absorb(v)
                            is String -> if (plain.isBlank()) plain = v
                        }
                    }
                }
            }

            val lines = if (synced.isNotBlank()) LrcParser.parse(synced) else emptyList()
            val result = LyricsResult(lines, plain.takeIf { it.isNotBlank() })
            if (!result.isEmpty) cache[key] = result
            result
        }

    private fun lrclibGet(title: String, artist: String?, durSec: Long): JSONObject? {
        val url = buildString {
            append("https://lrclib.net/api/get?track_name=").append(enc(title))
            if (!artist.isNullOrBlank()) append("&artist_name=").append(enc(artist))
            if (durSec > 0) append("&duration=").append(durSec)
        }
        val body = httpGet(url) ?: return null
        return runCatching { JSONObject(body) }.getOrNull()
    }

    /** Search and pick the best candidate: prefer synced lyrics whose duration is closest. */
    private fun lrclibSearchBest(title: String, artist: String?, durSec: Long): JSONObject? {
        val q = enc(
            listOfNotNull(title.takeIf { it.isNotBlank() }, artist?.takeIf { it.isNotBlank() })
                .joinToString(" ")
        )
        if (q.isBlank()) return null
        val body = httpGet("https://lrclib.net/api/search?q=$q") ?: return null
        return runCatching {
            val arr = JSONArray(body)
            var bestSynced: JSONObject? = null
            var bestDelta = Long.MAX_VALUE
            var firstPlain: JSONObject? = null
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.optString("syncedLyrics").isNotBlank()) {
                    val d = o.optLong("duration", -1)
                    val delta = if (durSec > 0 && d > 0) kotlin.math.abs(d - durSec) else 0L
                    if (delta < bestDelta) {
                        bestDelta = delta
                        bestSynced = o
                    }
                } else if (firstPlain == null && o.optString("plainLyrics").isNotBlank()) {
                    firstPlain = o
                }
            }
            bestSynced ?: firstPlain
        }.getOrNull()
    }

    private fun lyricsOvh(title: String, artist: String): String? {
        val body = httpGet("https://api.lyrics.ovh/v1/${enc(artist)}/${enc(title)}") ?: return null
        return runCatching {
            JSONObject(body).optString("lyrics").takeIf { it.isNotBlank() }
        }.getOrNull()
    }

    /** GET that retries once on a transient network error (but not on a real "not found"). */
    private fun httpGet(urlStr: String): String? {
        repeat(2) {
            try {
                val c = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 4000
                    readTimeout = 4000
                    setRequestProperty("User-Agent", "AutoLyricsHE/1.0 (personal use)")
                }
                return if (c.responseCode in 200..299) c.inputStream.bufferedReader().use { it.readText() } else null
            } catch (e: Exception) {
                // transient network error: loop and try once more
            }
        }
        return null
    }

    private fun cleanForSearch(s: String): String =
        s.replace(Regex("\\([^)]*\\)"), " ")
            .replace(Regex("\\[[^]]*]"), " ")
            .replace(Regex("(?i)\\b(feat\\.?|ft\\.?|with)\\b.*$"), " ")
            .replace(Regex("(?i)\\s*-\\s*topic\\b"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
}

object LrcParser {
    private val tag = Regex("\\[(\\d{1,2}):(\\d{2})(?:[.:](\\d{1,3}))?]")

    fun parse(lrc: String): List<MediaTracker.Line> {
        val out = ArrayList<MediaTracker.Line>()
        for (raw in lrc.lines()) {
            val matches = tag.findAll(raw).toList()
            if (matches.isEmpty()) continue
            val text = raw.substring(matches.last().range.last + 1).trim()
            for (m in matches) {
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val frac = m.groupValues[3]
                val ms = when (frac.length) {
                    0 -> 0L
                    1 -> frac.toLong() * 100
                    2 -> frac.toLong() * 10
                    else -> frac.take(3).toLong()
                }
                out.add(MediaTracker.Line(min * 60_000 + sec * 1000 + ms, text))
            }
        }
        return out.sortedBy { it.timeMs }
    }
}
