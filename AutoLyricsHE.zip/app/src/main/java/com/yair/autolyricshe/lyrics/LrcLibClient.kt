package com.yair.autolyricshe.lyrics

import com.yair.autolyricshe.media.MediaTracker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Result of a lyrics lookup: timed lines (may be empty) and/or full plain text (may be null). */
data class LyricsResult(
    val synced: List<MediaTracker.Line>,
    val plain: String?
) {
    val isEmpty: Boolean get() = synced.isEmpty() && plain.isNullOrBlank()
}

object LrcLibClient {

    suspend fun fetch(title: String?, artist: String?, durationMs: Long): LyricsResult =
        withContext(Dispatchers.IO) {
            if (title.isNullOrBlank()) return@withContext LyricsResult(emptyList(), null)
            val durSec = if (durationMs > 0) durationMs / 1000 else 0L

            var synced = ""
            var plain = ""

            // 1) LRCLIB exact get -> may contain both synced + plain
            lrclibGet(title, artist, durSec)?.let { obj ->
                synced = obj.optString("syncedLyrics")
                plain = obj.optString("plainLyrics")
            }

            // 2) LRCLIB search if nothing useful yet
            if (synced.isBlank() && plain.isBlank()) {
                lrclibSearch(title, artist)?.let { obj ->
                    synced = obj.optString("syncedLyrics")
                    plain = obj.optString("plainLyrics")
                }
            }

            // 3) lyrics.ovh as a last resort for plain text only
            if (plain.isBlank() && !artist.isNullOrBlank()) {
                lyricsOvh(title, artist)?.let { plain = it }
            }

            val lines = if (synced.isNotBlank()) LrcParser.parse(synced) else emptyList()
            LyricsResult(lines, plain.takeIf { it.isNotBlank() })
        }

    private fun lrclibGet(title: String, artist: String?, durSec: Long): JSONObject? {
        val url = buildString {
            append("https://lrclib.net/api/get?track_name=").append(enc(title))
            if (!artist.isNullOrBlank()) append("&artist_name=").append(enc(artist))
            if (durSec > 0) append("&duration=").append(durSec)
        }
        val body = httpGet(url) ?: return null
        return runCatching { JSONObject(body) }.getOrNull()
    }

    private fun lrclibSearch(title: String, artist: String?): JSONObject? {
        val ct = cleanForSearch(title)
        val ca = artist?.let { cleanForSearch(it) }
        val q = enc(listOfNotNull(ct.takeIf { it.isNotBlank() } ?: title, ca?.takeIf { it.isNotBlank() }).joinToString(" "))
        val body = httpGet("https://lrclib.net/api/search?q=$q") ?: return null
        return runCatching {
            val arr = JSONArray(body)
            var firstWithPlain: JSONObject? = null
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.optString("syncedLyrics").isNotBlank()) return o
                if (firstWithPlain == null && o.optString("plainLyrics").isNotBlank()) firstWithPlain = o
            }
            firstWithPlain
        }.getOrNull()
    }

    private fun lyricsOvh(title: String, artist: String): String? {
        val body = httpGet("https://api.lyrics.ovh/v1/${enc(artist)}/${enc(title)}") ?: return null
        return runCatching {
            JSONObject(body).optString("lyrics").takeIf { it.isNotBlank() }
        }.getOrNull()
    }

    private fun httpGet(urlStr: String): String? = runCatching {
        val c = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000
            readTimeout = 8000
            setRequestProperty("User-Agent", "AutoLyricsHE/1.0 (personal use)")
        }
        if (c.responseCode in 200..299) c.inputStream.bufferedReader().use { it.readText() } else null
    }.getOrNull()

    private fun cleanForSearch(s: String): String =
        s.replace(Regex("\\([^)]*\\)"), " ")
            .replace(Regex("\\[[^]]*]"), " ")
            .replace(Regex("(?i)\\b(feat\\.?|ft\\.?|with)\\b.*$"), " ")
            .replace(Regex("(?i)\\s*-\\s*topic\\b"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
}

object LrcParser {
    private val tag = Regex("\\[(\\d{1,2}):(\\d{2})(?:[.:](\\d{1,3}))?]")

    fun parse(lrc: String): List<MediaTracker.Line> {
        val out = ArrayList<MediaTracker.Line>()
        for (raw in lrc.lines()) {
            val matches = tag.findAll(raw).toList()
            if (matches.isEmpty()) continue
            val text = raw.substring(matches.last().range.last + 1).trim()
            for (m in matches) {
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val frac = m.groupValues[3]
                val ms = when (frac.length) {
                    0 -> 0L
                    1 -> frac.toLong() * 100
                    2 -> frac.toLong() * 10
                    else -> frac.take(3).toLong()
                }
                out.add(MediaTracker.Line(min * 60_000 + sec * 1000 + ms, text))
            }
        }
        return out.sortedBy { it.timeMs }
    }
}
