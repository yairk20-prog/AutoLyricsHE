package com.yair.autolyricshe.media

import android.content.ComponentName
import android.content.Context
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * NotificationListenerService is the only way a 3rd-party app can read which media
 * session (Spotify / YouTube Music / etc.) is currently active and its playback position.
 * NOTE: the media session exposes title + artist + duration, NOT a YouTube videoId,
 * which is why live recordings can't be matched the way YT Music itself does.
 */
class MediaListenerService : NotificationListenerService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var sessionManager: MediaSessionManager? = null
    private var controller: MediaController? = null
    private var ticker: kotlinx.coroutines.Job? = null

    private val controllerCallback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = pushMetadata(metadata)
        override fun onSessionDestroyed() {
            controller = null
            MediaTracker.onIdle()
        }
    }

    private val sessionsChangedListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> pickController(list) }

    override fun onListenerConnected() {
        val comp = ComponentName(this, MediaListenerService::class.java)
        val msm = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        sessionManager = msm
        try {
            msm.addOnActiveSessionsChangedListener(sessionsChangedListener, comp)
            pickController(msm.getActiveSessions(comp))
        } catch (_: SecurityException) {
            // Notification access not granted yet.
        }
        startTicker()
    }

    override fun onListenerDisconnected() = stopAll()

    private fun pickController(list: List<MediaController>?) {
        // Ignore our own session; prefer something actually playing, else the first.
        val own = packageName
        val candidates = list?.filter { it.packageName != own }
        val chosen = candidates?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: candidates?.firstOrNull()

        if (chosen?.sessionToken == controller?.sessionToken) {
            chosen?.let { pushMetadata(it.metadata) }
            return
        }
        controller?.unregisterCallback(controllerCallback)
        controller = chosen
        controller?.registerCallback(controllerCallback)
        pushMetadata(controller?.metadata)
    }

    private fun pushMetadata(m: MediaMetadata?) {
        if (m == null) return
        val title = clean(m.getString(MediaMetadata.METADATA_KEY_TITLE))
        val artist = m.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
        val duration = m.getLong(MediaMetadata.METADATA_KEY_DURATION)
        MediaTracker.onTrackChanged(title, artist, duration, scope)
    }

    /** Strips streaming-quality tags some players inject, e.g. "Song [Lossless]". */
    private fun clean(s: String?): String? =
        s?.replace(Regex("\\s*[\\[(](?:lossless|hi-?res|master|dolby[^\\])]*)[\\])]", RegexOption.IGNORE_CASE), "")
            ?.trim()

    private fun startTicker() {
        ticker?.cancel()
        ticker = scope.launch {
            while (isActive) {
                val ps = controller?.playbackState
                if (ps != null) {
                    val pos = if (ps.state == PlaybackState.STATE_PLAYING) {
                        ps.position + ((SystemClock.elapsedRealtime() - ps.lastPositionUpdateTime) * ps.playbackSpeed).toLong()
                    } else {
                        ps.position
                    }
                    MediaTracker.onPosition(pos)
                }
                delay(200)
            }
        }
    }

    private fun stopAll() {
        ticker?.cancel()
        controller?.unregisterCallback(controllerCallback)
        controller = null
        try {
            sessionManager?.removeOnActiveSessionsChangedListener(sessionsChangedListener)
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        stopAll()
        scope.cancel()
        super.onDestroy()
    }
}
