package com.yair.autolyricshe

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.yair.autolyricshe.media.MediaTracker
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btnAccess).setOnClickListener {
            // Opens the system screen where the user enables notification access for this app.
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        val tv = findViewById<TextView>(R.id.tvStatus)
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                MediaTracker.state.collect { s ->
                    tv.text = if (s.lines.isEmpty() || s.currentIndex < 0) {
                        s.status
                    } else buildString {
                        appendLine(s.headerTitle)
                        appendLine()
                        val i = s.currentIndex
                        for (j in (i - 1)..(i + 2)) {
                            if (j in s.lines.indices) {
                                val mark = if (j == i) "▶  " else "    "
                                appendLine(mark + s.lines[j].text.ifBlank { "♪" })
                            }
                        }
                    }
                }
            }
        }
    }
}
