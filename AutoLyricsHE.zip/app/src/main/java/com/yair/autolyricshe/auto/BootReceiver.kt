package com.yair.autolyricshe.auto

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Present so Android Auto re-scans and discovers our MediaBrowserService after the app is
 * (re)installed or the phone boots. The MediaBrowserService itself is bound by Android Auto
 * on demand; this receiver just exists to trigger that re-discovery.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        // No-op: the manifest registration is what matters for re-discovery.
    }
}
