package com.yair.autolyricshe.media

import com.yair.autolyricshe.lyrics.LrcLibClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Single source of truth shared between the Android Auto screen and the phone UI.
 * Holds the current track, its lyrics (synced and/or plain), and which line is highlighted now.
 */
object MediaTracker {

    data class Line(val timeMs: Long, val text: String)

    data class UiState(
        val headerTitle: String = "מילים ברכב",
        val status: String = "ממתין למוזיקה…",
        val lines: List<Line> = emptyList(),   // synced lines (empty if none)
        val currentIndex: Int = -1,
        val plain: String? = null              // full lyrics text when not synced
    ) {
        val hasSync: Boolean get() = lines.isNotEmpty()
        val refreshKey: String get() = "$currentIndex|$status|$headerTitle|${lines.size}|${plain?.length}"
    }

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    @Volatile private var currentTrackKey: String? = null
    @Volatile private var lines: List<Line> = emptyList()

    fun onTrackChanged(title: String?, artist: String?, durationMs: Long, scope: CoroutineScope) {
        if (title.isNullOrBlank()) return
        val key = "$title|$artist"
        if (key == currentTrackKey) return
        currentTrackKey = key
        lines = emptyList()

        val header = listOfNotNull(title, artist?.takeIf { it.isNotBlank() }).joinToString(" • ")
        _state.value = UiState(headerTitle = header, status = "טוען מילים…")

        scope.launch {
            val result = runCatching { LrcLibClient.fetch(title, artist, durationMs) }.getOrNull()
            if (key != currentTrackKey) return@launch

            when {
                result == null || result.isEmpty -> {
                    lines = emptyList()
                    _state.value = _state.value.copy(
                        status = "לא נמצאו מילים לשיר הזה", lines = emptyList(), currentIndex = -1, plain = null
                    )
                }
                result.synced.isNotEmpty() -> {
                    lines = result.synced
                    _state.value = _state.value.copy(
                        status = "", lines = result.synced, currentIndex = 0, plain = result.plain
                    )
                }
                else -> {
                    // plain text only (not synced)
                    lines = emptyList()
                    _state.value = _state.value.copy(
                        status = "", lines = emptyList(), currentIndex = -1, plain = result.plain
                    )
                }
            }
        }
    }

    fun onPosition(posMs: Long) {
        val l = lines
        if (l.isEmpty()) return
        var idx = 0
        for (i in l.indices) {
            if (l[i].timeMs <= posMs) idx = i else break
        }
        if (idx != _state.value.currentIndex) {
            _state.value = _state.value.copy(currentIndex = idx)
        }
    }

    fun onIdle() {
        currentTrackKey = null
        lines = emptyList()
        _state.value = UiState()
    }
}
