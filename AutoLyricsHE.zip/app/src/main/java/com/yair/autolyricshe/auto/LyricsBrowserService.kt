package com.yair.autolyricshe.auto

import android.os.Bundle
import android.support.v4.media.MediaBrowserCompat
import android.support.v4.media.MediaDescriptionCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import androidx.media.MediaBrowserServiceCompat
import com.yair.autolyricshe.media.MediaTracker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min

/**
 * Android Auto reaches the app through this MediaBrowserService (the "media app" approach).
 * Unlike Car App Library apps, media apps CAN be sideloaded and appear in Android Auto.
 * We present the current lyric lines as a browsable list and refresh it as the song plays.
 */
class LyricsBrowserService : MediaBrowserServiceCompat() {

    private lateinit var session: MediaSessionCompat
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var collectJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        session = MediaSessionCompat(this, "AutoLyricsSession").apply {
            setPlaybackState(
                PlaybackStateCompat.Builder()
                    .setState(PlaybackStateCompat.STATE_PAUSED, 0, 1f)
                    .setActions(PlaybackStateCompat.ACTION_PLAY_PAUSE)
                    .build()
            )
            isActive = true
        }
        sessionToken = session.sessionToken

        // Refresh the lyric list whenever the active line (or status) changes.
        collectJob = scope.launch {
            MediaTracker.state.map { it.refreshKey }.distinctUntilChanged().collect {
                notifyChildrenChanged(ROOT_ID)
            }
        }
    }

    override fun onGetRoot(clientPackageName: String, clientUid: Int, rootHints: Bundle?): BrowserRoot {
        return BrowserRoot(ROOT_ID, null)
    }

    override fun onLoadChildren(parentId: String, result: Result<MutableList<MediaBrowserCompat.MediaItem>>) {
        val items = ArrayList<MediaBrowserCompat.MediaItem>()
        if (parentId == ROOT_ID) {
            val s = MediaTracker.state.value
            when {
                s.lines.isNotEmpty() && s.currentIndex >= 0 -> {
                    val from = max(0, s.currentIndex - 1)
                    val to = min(s.lines.size - 1, s.currentIndex + 4)
                    for (i in from..to) {
                        val prefix = if (i == s.currentIndex) "\u25B6  " else ""
                        items.add(item("line_$i", prefix + s.lines[i].text.ifBlank { "\u266A" }))
                    }
                }
                s.plain != null -> {
                    s.plain.lines().filter { it.isNotBlank() }.take(60).forEachIndexed { idx, line ->
                        items.add(item("p_$idx", line))
                    }
                }
                else -> items.add(item("status", s.status.ifBlank { "\u2026" }))
            }
        }
        result.sendResult(items)
    }

    private fun item(id: String, title: String): MediaBrowserCompat.MediaItem {
        val desc = MediaDescriptionCompat.Builder()
            .setMediaId(id)
            .setTitle(title)
            .build()
        return MediaBrowserCompat.MediaItem(desc, MediaBrowserCompat.MediaItem.FLAG_PLAYABLE)
    }

    override fun onDestroy() {
        collectJob?.cancel()
        scope.cancel()
        session.release()
        super.onDestroy()
    }

    companion object {
        private const val ROOT_ID = "root"
    }
}
