package com.yair.autolyricshe

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.yair.autolyricshe.media.MediaTracker
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private val gold = Color.parseColor("#E8C36A")
    private val dim = Color.parseColor("#7A7A85")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btn = findViewById<Button>(R.id.btnAccess)
        val tvTitle = findViewById<TextView>(R.id.tvTitle)
        val tvLyrics = findViewById<TextView>(R.id.tvLyrics)
        val scroll = findViewById<ScrollView>(R.id.scroll)

        btn.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                MediaTracker.state.collect { s ->
                    tvTitle.text = if (s.hasSync || s.plain != null) s.headerTitle else ""
                    when {
                        s.hasSync -> renderSynced(tvLyrics, scroll, s)
                        s.plain != null -> {
                            tvLyrics.setTextColor(dim)
                            tvLyrics.text = s.plain
                        }
                        else -> {
                            tvLyrics.setTextColor(dim)
                            tvLyrics.text = s.status
                        }
                    }
                }
            }
        }
    }

    private fun renderSynced(tvLyrics: TextView, scroll: ScrollView, s: MediaTracker.UiState) {
        val sb = SpannableStringBuilder()
        var currentStart = 0
        for (i in s.lines.indices) {
            val start = sb.length
            sb.append(s.lines[i].text.ifBlank { "♪" }).append("\n\n")
            val end = sb.length
            if (i == s.currentIndex) {
                currentStart = start
                sb.setSpan(ForegroundColorSpan(gold), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                sb.setSpan(StyleSpan(Typeface.BOLD), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                sb.setSpan(RelativeSizeSpan(1.25f), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            } else {
                sb.setSpan(ForegroundColorSpan(dim), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }
        tvLyrics.text = sb
        scroll.post {
            try {
                val layout = tvLyrics.layout ?: return@post
                val line = layout.getLineForOffset(currentStart)
                val y = layout.getLineTop(line)
                scroll.smoothScrollTo(0, (y - scroll.height / 2).coerceAtLeast(0))
            } catch (_: Exception) {
            }
        }
    }
}
