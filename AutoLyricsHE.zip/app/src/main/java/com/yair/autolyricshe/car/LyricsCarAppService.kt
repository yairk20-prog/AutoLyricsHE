package com.yair.autolyricshe.car

import android.content.Intent
import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.Session
import androidx.car.app.CarAppService
import androidx.car.app.model.Action
import androidx.car.app.model.Pane
import androidx.car.app.model.PaneTemplate
import androidx.car.app.model.Row
import androidx.car.app.model.Template
import androidx.car.app.validation.HostValidator
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.yair.autolyricshe.media.MediaTracker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min

class LyricsCarAppService : CarAppService() {
    // ALLOW_ALL is fine for a sideloaded personal app. For Play Store you'd validate the host.
    override fun createHostValidator(): HostValidator = HostValidator.ALLOW_ALL_HOSTS_VALIDATOR
    override fun onCreateSession(): Session = LyricsSession()
}

class LyricsSession : Session() {
    override fun onCreateScreen(intent: Intent): Screen = LyricsScreen(carContext)
}

class LyricsScreen(carContext: CarContext) : Screen(carContext), DefaultLifecycleObserver {

    private var collectJob: Job? = null

    init {
        lifecycle.addObserver(this)
    }

    override fun onStart(owner: LifecycleOwner) {
        // Redraw the car screen only when the visible window actually changes -> safe & smooth.
        collectJob = CoroutineScope(Dispatchers.Main).launch {
            MediaTracker.state
                .map { it.refreshKey }
                .distinctUntilChanged()
                .collect { invalidate() }
        }
    }

    override fun onStop(owner: LifecycleOwner) {
        collectJob?.cancel()
        collectJob = null
    }

    override fun onGetTemplate(): Template {
        val state = MediaTracker.state.value
        val pane = Pane.Builder()

        if (state.lines.isEmpty() || state.currentIndex < 0) {
            val msg = when {
                state.plain != null -> "מילים מלאות זמינות במסך הטלפון (לא מסונכרן)"
                else -> state.status.ifBlank { "…" }
            }
            pane.addRow(Row.Builder().setTitle(msg).build())
        } else {
            val idx = state.currentIndex
            val from = max(0, idx - 1)
            val to = min(state.lines.size - 1, idx + 2)
            for (i in from..to) {
                val raw = state.lines[i].text.ifBlank { "♪" }
                val marker = if (i == idx) "▶  " else "    "
                pane.addRow(Row.Builder().setTitle(marker + raw).build())
            }
        }

        return PaneTemplate.Builder(pane.build())
            .setTitle(state.headerTitle)
            .setHeaderAction(Action.APP_ICON)
            .build()
    }
}
