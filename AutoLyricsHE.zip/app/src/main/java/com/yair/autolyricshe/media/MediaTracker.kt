package com.yair.autolyricshe.media

import com.yair.autolyricshe.lyrics.LrcLibClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Single source of truth shared between the Android Auto screen and the phone UI.
 * Holds the current track, its synced lyrics, and which line should be highlighted now.
 */
object MediaTracker {

    data class Line(val timeMs: Long, val text: String)

    data class UiState(
        val headerTitle: String = "מילים ברכב",
        val status: String = "ממתין למוזיקה…",
        val lines: List<Line> = emptyList(),
        val currentIndex: Int = -1
    ) {
        // Used to decide when the Auto screen needs to redraw (refresh only on real change).
        val refreshKey: String get() = "$currentIndex|$status|$headerTitle|${lines.size}"
    }

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    @Volatile private var currentTrackKey: String? = null
    @Volatile private var lines: List<Line> = emptyList()

    /** Called whenever the playing track changes. Debounced so we only fetch once per song. */
    fun onTrackChanged(title: String?, artist: String?, durationMs: Long, scope: CoroutineScope) {
        if (title.isNullOrBlank()) return
        val key = "$title|$artist"
        if (key == currentTrackKey) return
        currentTrackKey = key
        lines = emptyList()

        val header = listOfNotNull(title, artist?.takeIf { it.isNotBlank() }).joinToString(" • ")
        _state.value = UiState(headerTitle = header, status = "טוען מילים…")

        scope.launch {
            val fetched = runCatching { LrcLibClient.fetch(title, artist, durationMs) }.getOrDefault(emptyList())
            if (key != currentTrackKey) return@launch // a newer song already started
            if (fetched.isNotEmpty()) {
                lines = fetched
                _state.value = _state.value.copy(status = "", lines = fetched, currentIndex = 0)
            } else {
                lines = emptyList()
                _state.value = _state.value.copy(status = "לא נמצאו מילים מסונכרנות לשיר הזה", lines = emptyList(), currentIndex = -1)
            }
        }
    }

    /** Called ~5x/second with the current playback position. Advances the highlighted line. */
    fun onPosition(posMs: Long) {
        val l = lines
        if (l.isEmpty()) return
        var idx = 0
        for (i in l.indices) {
            if (l[i].timeMs <= posMs) idx = i else break
        }
        if (idx != _state.value.currentIndex) {
            _state.value = _state.value.copy(currentIndex = idx)
        }
    }

    /** No music playing / session gone. */
    fun onIdle() {
        currentTrackKey = null
        lines = emptyList()
        _state.value = UiState()
    }
}
