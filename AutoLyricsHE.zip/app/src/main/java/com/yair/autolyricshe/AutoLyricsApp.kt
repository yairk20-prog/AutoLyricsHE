package com.yair.autolyricshe

import android.app.Application

/**
 * Application class. Mirrors auto-lyrics' structure. Kept minimal: the media
 * pipeline (MediaTracker) is a singleton that initializes lazily, so nothing
 * needs to start here. Having an Application entry simply matches the reference
 * app exactly so Android Auto sees an identically-shaped package.
 */
class AutoLyricsApp : Application()
