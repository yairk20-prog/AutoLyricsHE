package com.yair.autolyricshe.lyrics

import com.yair.autolyricshe.media.MediaTracker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Pulls time-synced lyrics from LRCLIB (https://lrclib.net) — a free, public, no-auth API.
 *
 * To swap in a different source later (e.g. your own server), only this object needs to change:
 * return a List<MediaTracker.Line> sorted by timeMs.
 */
object LrcLibClient {

    suspend fun fetch(title: String?, artist: String?, durationMs: Long): List<MediaTracker.Line> =
        withContext(Dispatchers.IO) {
            if (title.isNullOrBlank()) return@withContext emptyList()
            val durSec = if (durationMs > 0) durationMs / 1000 else 0L
            val synced = tryGet(title, artist, durSec) ?: trySearch(title, artist)
            if (synced.isNullOrBlank()) emptyList() else LrcParser.parse(synced)
        }

    private fun tryGet(title: String, artist: String?, durSec: Long): String? {
        val url = buildString {
            append("https://lrclib.net/api/get?track_name=").append(enc(title))
            if (!artist.isNullOrBlank()) append("&artist_name=").append(enc(artist))
            if (durSec > 0) append("&duration=").append(durSec)
        }
        val body = httpGet(url) ?: return null
        return runCatching {
            JSONObject(body).optString("syncedLyrics").ifBlank { null }
        }.getOrNull()
    }

    private fun trySearch(title: String, artist: String?): String? {
        val q = enc(listOfNotNull(title, artist?.takeIf { it.isNotBlank() }).joinToString(" "))
        val body = httpGet("https://lrclib.net/api/search?q=$q") ?: return null
        return runCatching {
            val arr = JSONArray(body)
            for (i in 0 until arr.length()) {
                val s = arr.getJSONObject(i).optString("syncedLyrics")
                if (s.isNotBlank()) return s
            }
            null
        }.getOrNull()
    }

    private fun httpGet(urlStr: String): String? = runCatching {
        val c = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000
            readTimeout = 8000
            setRequestProperty("User-Agent", "AutoLyricsHE/1.0 (personal use)")
        }
        if (c.responseCode in 200..299) c.inputStream.bufferedReader().use { it.readText() } else null
    }.getOrNull()

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
}

object LrcParser {
    private val tag = Regex("\\[(\\d{1,2}):(\\d{2})(?:[.:](\\d{1,3}))?]")

    fun parse(lrc: String): List<MediaTracker.Line> {
        val out = ArrayList<MediaTracker.Line>()
        for (raw in lrc.lines()) {
            val matches = tag.findAll(raw).toList()
            if (matches.isEmpty()) continue
            val text = raw.substring(matches.last().range.last + 1).trim()
            for (m in matches) {
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val frac = m.groupValues[3]
                val ms = when (frac.length) {
                    0 -> 0L
                    1 -> frac.toLong() * 100
                    2 -> frac.toLong() * 10
                    else -> frac.take(3).toLong()
                }
                out.add(MediaTracker.Line(min * 60_000 + sec * 1000 + ms, text))
            }
        }
        return out.sortedBy { it.timeMs }
    }
}
